# Smart Attendance System

เว็บไซต์ระบบเช็คชื่อนักเรียนอัตโนมัติด้วย 8-bit Register

## GitHub Pages
หลังอัปโหลด `index.html` ไปยัง repository แล้ว ให้เปิด:
Settings → Pages → Build and deployment → Source: Deploy from a branch
เลือก branch `main` และ folder `/(root)` แล้วกด Save
